#!/usr/bin/env python3
"""timestamp -- convert between epoch seconds and ISO-8601 timestamps (UTC)."""

import argparse
import datetime
import sys


def build_parser():
    parser = argparse.ArgumentParser(
        prog="timestamp",
        description="Convert epoch seconds to ISO-8601 UTC, or an ISO-8601 "
                    "timestamp to epoch seconds.",
    )
    parser.add_argument(
        "value", nargs="?", default=None,
        help="epoch seconds or ISO-8601 timestamp; omit when using --now")
    parser.add_argument(
        "--now", action="store_true",
        help="print the current UTC epoch seconds")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.now:
        if args.value is not None:
            parser.error("--now takes no value")
        moment = datetime.datetime.now(datetime.timezone.utc)
        print(int(moment.timestamp()))
        return 0

    if args.value is None:
        parser.error("provide an epoch value, an ISO-8601 timestamp, or --now")

    text = args.value.strip()
    try:
        epoch = float(text)
    except ValueError:
        iso_text = text[:-1] + "+00:00" if text.endswith("Z") else text
        try:
            parsed = datetime.datetime.fromisoformat(iso_text)
        except ValueError:
            print("timestamp: cannot interpret value: %s" % text, file=sys.stderr)
            return 1
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=datetime.timezone.utc)
        print(int(parsed.timestamp()))
        return 0

    try:
        moment = datetime.datetime.fromtimestamp(epoch, tz=datetime.timezone.utc)
    except (OverflowError, OSError, ValueError) as exc:
        print("timestamp: out-of-range epoch: %s" % exc, file=sys.stderr)
        return 1
    print(moment.strftime("%Y-%m-%dT%H:%M:%SZ"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
