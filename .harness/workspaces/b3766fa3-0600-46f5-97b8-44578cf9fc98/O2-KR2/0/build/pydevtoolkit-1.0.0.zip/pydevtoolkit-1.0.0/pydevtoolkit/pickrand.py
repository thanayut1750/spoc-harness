#!/usr/bin/env python3
"""pickrand -- pick N random lines from a file or stdin (seedable)."""

import argparse
import random
import sys


def build_parser():
    parser = argparse.ArgumentParser(
        prog="pickrand",
        description="Pick random lines from a file or stdin; seedable for "
                    "reproducible output.",
    )
    parser.add_argument(
        "file", nargs="?", default="-",
        help="input file, one item per line (default: '-' reads stdin)")
    parser.add_argument(
        "-n", "--count", type=int, default=1, metavar="N",
        help="how many lines to pick (default: 1)")
    parser.add_argument(
        "-s", "--seed", type=int, default=None, metavar="INT",
        help="random seed for reproducible picks")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.file == "-":
            lines = sys.stdin.read().splitlines()
        else:
            with open(args.file, "r", encoding="utf-8") as handle:
                lines = handle.read().splitlines()
    except OSError as exc:
        print("pickrand: cannot read %s: %s" % (args.file, exc), file=sys.stderr)
        return 1

    lines = [line for line in lines if line != ""]
    if not lines:
        print("pickrand: no input lines", file=sys.stderr)
        return 1
    count = max(0, min(args.count, len(lines)))
    rng = random.Random(args.seed)
    for line in rng.sample(lines, count):
        print(line)
    return 0


if __name__ == "__main__":
    sys.exit(main())
