"""Tests for pydevtoolkit.hexdump."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import hexdump as mod  # noqa: E402


class HexdumpTests(unittest.TestCase):
    def run_tool_bytes(self, argv, stdin_bytes=b""):
        """Run main() with binary stdin (the tool reads sys.stdin.buffer)."""
        out, err = io.StringIO(), io.StringIO()
        fake_stdin = io.TextIOWrapper(io.BytesIO(stdin_bytes), encoding="utf-8")
        old_stdin = sys.stdin
        sys.stdin = fake_stdin
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
            fake_stdin.close()
        return code, out.getvalue(), err.getvalue()

    def test_stdin_dump_offsets_and_ascii(self):
        code, out, err = self.run_tool_bytes([], b"ABC")
        self.assertEqual(code, 0, err)
        self.assertTrue(out.startswith("00000000  41 42 43"))
        self.assertIn("|ABC|", out)
        self.assertEqual(len(out.splitlines()), 1)

    def test_printable_filter_for_control_bytes(self):
        code, out, err = self.run_tool_bytes([], b"AB\n")
        self.assertEqual(code, 0, err)
        self.assertTrue(out.startswith("00000000  41 42 0a"))
        self.assertIn("|AB.|", out)

    def test_columns_option_splits_lines(self):
        code, out, err = self.run_tool_bytes(["-c", "4"], b"ABCDEFGH")
        self.assertEqual(code, 0, err)
        lines = out.splitlines()
        self.assertEqual(len(lines), 2)
        self.assertTrue(lines[0].startswith("00000000  41 42 43 44"))
        self.assertTrue(lines[1].startswith("00000004  45 46 47 48"))

    def test_file_input_matches_stdin(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "blob.bin")
            with open(path, "wb") as handle:
                handle.write(b"hello")
            code, out, err = self.run_tool_bytes([path], b"hello")
            self.assertEqual(code, 0, err)
            self.assertIn("|hello|", out)
            self.assertEqual(out.splitlines()[0][:10], "00000000  ")

    def test_missing_file_exit_one(self):
        code, out, err = self.run_tool_bytes(["no_such_blob.bin"])
        self.assertEqual(code, 1)
        self.assertIn("cannot read", err)

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.hexdump", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
