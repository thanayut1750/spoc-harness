"""Tests for pydevtoolkit.csvstat."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import csvstat as mod  # noqa: E402


class CsvstatTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_counts_and_numeric_stats_from_stdin(self):
        code, out, err = self.run_tool(
            [], "name,score\nann,91\nbob,84\ncid,77\n")
        self.assertEqual(code, 0, err)
        self.assertIn("columns: 2", out)
        self.assertIn("data_rows: 3", out)
        self.assertIn("name: text (3 distinct)", out)
        self.assertIn("score: min=77 max=91 mean=84.0000 (n=3)", out)

    def test_file_input_with_custom_delimiter(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "data.csv")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("name;score\nalice;1.5\nbob;2.5\n")
            code, out, err = self.run_tool(["-d", ";", path])
            self.assertEqual(code, 0, err)
            self.assertIn("columns: 2", out)
            self.assertIn("data_rows: 2", out)
            self.assertIn("score: min=1.5 max=2.5 mean=2.0000 (n=2)", out)

    def test_missing_file_reports_error(self):
        code, out, err = self.run_tool(["/nonexistent/nope.csv"])
        self.assertEqual(code, 1)
        self.assertIn("cannot read", err)

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.csvstat", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
