"""Tests for pydevtoolkit.b64."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import b64 as mod  # noqa: E402


class B64Tests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_encode_from_stdin(self):
        code, out, err = self.run_tool([], "encode me")
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "ZW5jb2RlIG1l\n")

    def test_decode_round_trip(self):
        code, out, err = self.run_tool(["-d"], "ZW5jb2RlIG1l\n")
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "encode me\n")
        # Full round trip through a temporary file.
        with tempfile.TemporaryDirectory() as tmp:
            enc_path = os.path.join(tmp, "enc.txt")
            with open(enc_path, "w", encoding="utf-8") as handle:
                handle.write("cGFja2FnZWQgcGF5bG9hZA==\n")
            code, out, err = self.run_tool(["-d", enc_path])
            self.assertEqual(code, 0, err)
            self.assertEqual(out, "packaged payload\n")

    def test_wrap_option_bounds_line_length(self):
        code, out, err = self.run_tool(["-w", "40"], "a" * 100)
        self.assertEqual(code, 0, err)
        lines = out.splitlines()
        self.assertGreater(len(lines), 1)
        for line in lines:
            self.assertLessEqual(len(line), 40)
        joined = "".join(lines)
        code, out, err = self.run_tool(["-d"], joined)
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "a" * 100 + "\n")

    def test_invalid_base64_reports_error(self):
        code, out, err = self.run_tool(["-d"], "!!!not-base64!!!")
        self.assertEqual(code, 1)
        self.assertIn("cannot decode", err)

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.b64", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
