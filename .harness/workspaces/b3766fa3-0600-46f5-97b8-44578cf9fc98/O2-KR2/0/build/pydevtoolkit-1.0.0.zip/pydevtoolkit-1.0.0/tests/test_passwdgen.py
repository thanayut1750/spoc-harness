"""Tests for pydevtoolkit.passwdgen."""

import contextlib
import io
import os
import subprocess
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import passwdgen as mod  # noqa: E402


class PasswdgenTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_seeded_output_reproducible(self):
        first = self.run_tool(["--seed", "42", "-l", "12"])
        second = self.run_tool(["--seed", "42", "-l", "12"])
        self.assertEqual(first[0], 0)
        self.assertEqual(first, second)
        password = first[1].strip()
        self.assertEqual(len(password), 12)
        alphabet = mod.LOWER + mod.UPPER + mod.DIGITS + mod.SYMBOLS
        self.assertTrue(all(char in alphabet for char in password))

    def test_count_and_length(self):
        code, out, err = self.run_tool(["--seed", "1", "-l", "8", "-n", "3"])
        self.assertEqual(code, 0, err)
        lines = out.splitlines()
        self.assertEqual(len(lines), 3)
        self.assertTrue(all(len(line) == 8 for line in lines))

    def test_no_symbols_restricts_alphabet(self):
        allowed = set(mod.LOWER + mod.UPPER + mod.DIGITS)
        code, out, err = self.run_tool(["--seed", "2", "-l", "40", "--no-symbols"])
        self.assertEqual(code, 0, err)
        password = out.strip()
        self.assertEqual(len(password), 40)
        self.assertTrue(all(char in allowed for char in password))

    def test_default_secrets_generator(self):
        code, out, err = self.run_tool(["-l", "16"])
        self.assertEqual(code, 0, err)
        alphabet = set(mod.LOWER + mod.UPPER + mod.DIGITS + mod.SYMBOLS)
        password = out.strip()
        self.assertEqual(len(password), 16)
        self.assertTrue(all(char in alphabet for char in password))

    def test_length_below_four_rejected(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err), \
                contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(SystemExit) as ctx:
                mod.main(["-l", "3", "--seed", "1"])
        self.assertEqual(ctx.exception.code, 2)
        self.assertIn("--length must be >= 4", err.getvalue())

    def test_count_below_one_rejected(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err), \
                contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(SystemExit) as ctx:
                mod.main(["-n", "0", "--seed", "1"])
        self.assertEqual(ctx.exception.code, 2)
        self.assertIn("--count must be >= 1", err.getvalue())

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.passwdgen", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
