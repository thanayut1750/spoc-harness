#!/usr/bin/env python3
"""difftxt -- unified diff of two text files (difflib)."""

import argparse
import difflib
import sys


def build_parser():
    parser = argparse.ArgumentParser(
        prog="difftxt",
        description="Print a unified line diff between two text files.",
    )
    parser.add_argument("file1", help="first (original) file")
    parser.add_argument("file2", help="second (modified) file")
    parser.add_argument(
        "-c", "--context", type=int, default=3, metavar="N",
        help="context lines shown around changes (default: 3)")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        with open(args.file1, "r", encoding="utf-8") as handle:
            before = handle.readlines()
        with open(args.file2, "r", encoding="utf-8") as handle:
            after = handle.readlines()
    except OSError as exc:
        print("difftxt: %s" % exc, file=sys.stderr)
        return 1
    diff = list(difflib.unified_diff(
        before, after,
        fromfile=args.file1, tofile=args.file2, n=args.context))
    if diff:
        sys.stdout.write("".join(diff))
    else:
        print("no differences")
    return 0


if __name__ == "__main__":
    sys.exit(main())
