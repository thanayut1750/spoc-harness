"""Tests for pydevtoolkit.utfcheck."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import utfcheck as mod  # noqa: E402


class UtfcheckTests(unittest.TestCase):
    def run_tool_bytes(self, argv, stdin_bytes=b""):
        """Run main() with binary stdin (the tool reads sys.stdin.buffer)."""
        out, err = io.StringIO(), io.StringIO()
        fake_stdin = io.TextIOWrapper(io.BytesIO(stdin_bytes), encoding="utf-8")
        old_stdin = sys.stdin
        sys.stdin = fake_stdin
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
            fake_stdin.close()
        return code, out.getvalue(), err.getvalue()

    def test_valid_ascii_reports_zero_non_ascii(self):
        code, out, err = self.run_tool_bytes([], b"hello world\n")
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "utf8: valid\nbom: no\nnon_ascii_total: 0\n")

    def test_non_ascii_reported_with_position_and_name(self):
        code, out, err = self.run_tool_bytes([], "ok \u2014\n".encode("utf-8"))
        self.assertEqual(code, 0, err)
        self.assertIn("utf8: valid", out)
        self.assertIn("non_ascii: line=1 col=4 U+2014 EM DASH", out)
        self.assertIn("non_ascii_total: 1", out)

    def test_bom_detected(self):
        code, out, err = self.run_tool_bytes([], b"\xef\xbb\xbfplain ascii\n")
        self.assertEqual(code, 0, err)
        self.assertIn("bom: yes", out)
        self.assertIn("U+FEFF", out)

    def test_invalid_utf8_exit_one(self):
        code, out, err = self.run_tool_bytes([], b"\xff\xfe bad\n")
        self.assertEqual(code, 1)
        self.assertIn("utf8: invalid", out)
        self.assertIn("bom: no", out)

    def test_max_flag_limits_listings(self):
        payload = "\u00e9\u00e9\u00e9\n".encode("utf-8")
        code, out, err = self.run_tool_bytes(["-m", "1"], payload)
        self.assertEqual(code, 0, err)
        self.assertEqual(out.count("non_ascii: line="), 1)
        self.assertIn("non_ascii_total: 3", out)

    def test_missing_file_exit_one(self):
        code, out, err = self.run_tool_bytes(["no_such_text.txt"])
        self.assertEqual(code, 1)
        self.assertIn("cannot read", err)

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.utfcheck", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
