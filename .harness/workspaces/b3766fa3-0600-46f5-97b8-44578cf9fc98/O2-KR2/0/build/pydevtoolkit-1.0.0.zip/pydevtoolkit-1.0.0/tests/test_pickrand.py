"""Tests for pydevtoolkit.pickrand."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import pickrand as mod  # noqa: E402


class PickrandTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_seeded_picks_are_reproducible(self):
        first = self.run_tool(["-s", "7", "-n", "2"], "a\nb\nc\nd\n")
        second = self.run_tool(["-s", "7", "-n", "2"], "a\nb\nc\nd\n")
        self.assertEqual(first[0], 0)
        self.assertEqual(first, second)
        picked = first[1].splitlines()
        self.assertEqual(len(picked), 2)
        self.assertTrue(set(picked) <= {"a", "b", "c", "d"})

    def test_count_clamped_to_line_total(self):
        code, out, err = self.run_tool(["-n", "100", "-s", "1"], "a\nb\nc\n")
        self.assertEqual(code, 0, err)
        self.assertEqual(sorted(out.splitlines()), ["a", "b", "c"])

    def test_default_count_is_one(self):
        code, out, err = self.run_tool(["-s", "3"], "x\ny\n")
        self.assertEqual(code, 0, err)
        self.assertEqual(len(out.splitlines()), 1)

    def test_file_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "items.txt")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("p\nq\nr\ns\n")
            code, out, err = self.run_tool(["-s", "5", "-n", "2", path])
            self.assertEqual(code, 0, err)
            self.assertEqual(len(out.splitlines()), 2)
            self.assertTrue(set(out.splitlines()) <= {"p", "q", "r", "s"})

    def test_empty_input_exit_one(self):
        code, out, err = self.run_tool([], "")
        self.assertEqual(code, 1)
        self.assertIn("no input lines", err)

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.pickrand", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
