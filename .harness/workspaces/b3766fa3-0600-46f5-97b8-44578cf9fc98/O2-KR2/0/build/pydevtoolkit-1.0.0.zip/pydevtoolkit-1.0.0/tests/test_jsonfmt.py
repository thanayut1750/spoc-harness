"""Tests for pydevtoolkit.jsonfmt."""

import contextlib
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import jsonfmt as mod  # noqa: E402


class JsonfmtTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_pretty_sort_and_indent(self):
        code, out, err = self.run_tool(["-s", "-i", "2"], '{"b": 2, "a": [1, 2]}')
        self.assertEqual(code, 0, err)
        self.assertEqual(json.loads(out), {"a": [1, 2], "b": 2})
        self.assertLess(out.index('"a"'), out.index('"b"'))
        self.assertIn('\n  "a": [\n    1,', out)

    def test_compact_and_file_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "in.json")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write('{"k": [1, 2], "v": "x"}')
            code, out, err = self.run_tool(["-c", path])
            self.assertEqual(code, 0, err)
            self.assertEqual(out.strip(), '{"k":[1,2],"v":"x"}')

    def test_invalid_json_reports_error(self):
        code, out, err = self.run_tool([], "{not json")
        self.assertEqual(code, 1)
        self.assertIn("invalid JSON", err)
        self.assertEqual(out, "")

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.jsonfmt", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
