#!/usr/bin/env python3
"""regexfind -- print regex matches (with optional groups) from a file or stdin."""

import argparse
import re
import sys


def build_parser():
    parser = argparse.ArgumentParser(
        prog="regexfind",
        description="Find regular-expression matches in a file or stdin and "
                    "print each match, optionally with capture groups.",
    )
    parser.add_argument("pattern", help="Python regular expression")
    parser.add_argument(
        "file", nargs="?", default="-",
        help="input file (default: '-' reads stdin)")
    parser.add_argument(
        "-g", "--groups", action="store_true",
        help="print capture groups after each match")
    parser.add_argument(
        "-i", "--ignore-case", action="store_true",
        help="case-insensitive matching")
    parser.add_argument(
        "-n", "--line-numbers", action="store_true",
        help="prefix each match with its 1-based line number")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    flags = re.IGNORECASE if args.ignore_case else 0
    try:
        pattern = re.compile(args.pattern, flags)
    except re.error as exc:
        print("regexfind: bad pattern: %s" % exc, file=sys.stderr)
        return 1
    try:
        if args.file == "-":
            lines = sys.stdin.read().splitlines()
        else:
            with open(args.file, "r", encoding="utf-8") as handle:
                lines = handle.read().splitlines()
    except OSError as exc:
        print("regexfind: cannot read %s: %s" % (args.file, exc), file=sys.stderr)
        return 1

    total = 0
    for number, line in enumerate(lines, start=1):
        for match in pattern.finditer(line):
            total += 1
            prefix = "%d:" % number if args.line_numbers else ""
            print("%s%s" % (prefix, match.group(0)))
            if args.groups:
                for group in match.groups():
                    print("  group: %s" % (group if group is not None else "<unset>"))
    if total == 0:
        print("no matches")
    return 0


if __name__ == "__main__":
    sys.exit(main())
