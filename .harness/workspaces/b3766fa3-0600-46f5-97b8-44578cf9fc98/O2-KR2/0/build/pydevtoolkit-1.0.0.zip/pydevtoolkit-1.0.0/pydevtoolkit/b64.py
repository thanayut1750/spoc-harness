#!/usr/bin/env python3
"""b64 -- base64 encode or decode text from a file or stdin."""

import argparse
import base64
import binascii
import sys


def build_parser():
    parser = argparse.ArgumentParser(
        prog="b64",
        description="Base64-encode or decode text read from a file or stdin.",
    )
    parser.add_argument(
        "file", nargs="?", default="-",
        help="input file (default: '-' reads stdin)")
    parser.add_argument(
        "-d", "--decode", action="store_true",
        help="decode base64 input back to text")
    parser.add_argument(
        "-w", "--wrap", type=int, default=76, metavar="N",
        help="wrap encoded output at N chars, 0 disables (default: 76)")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.file == "-":
            raw = sys.stdin.read()
        else:
            with open(args.file, "r", encoding="utf-8") as handle:
                raw = handle.read()
    except OSError as exc:
        print("b64: cannot read %s: %s" % (args.file, exc), file=sys.stderr)
        return 1

    if args.decode:
        try:
            text = base64.b64decode("".join(raw.split()), validate=True).decode("utf-8")
        except (binascii.Error, UnicodeDecodeError) as exc:
            print("b64: cannot decode input: %s" % exc, file=sys.stderr)
            return 1
        sys.stdout.write(text)
        if not text.endswith("\n"):
            sys.stdout.write("\n")
    else:
        encoded = base64.b64encode(raw.encode("utf-8")).decode("ascii")
        width = args.wrap if args.wrap and args.wrap > 0 else len(encoded) or 1
        lines = [encoded[i:i + width] for i in range(0, len(encoded), width)]
        sys.stdout.write("".join(line + "\n" for line in lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())
