#!/usr/bin/env python3
"""hashfile -- md5/sha1/sha256 digests for files or stdin."""

import argparse
import hashlib
import sys

ALGORITHMS = ("md5", "sha1", "sha256")


def _digest_stream(algorithm, chunks):
    digest = hashlib.new(algorithm)
    for chunk in chunks:
        digest.update(chunk)
    return digest.hexdigest()


def build_parser():
    parser = argparse.ArgumentParser(
        prog="hashfile",
        description="Print md5/sha1/sha256 digests of files or stdin.",
    )
    parser.add_argument(
        "files", nargs="*", default=["-"],
        help="files to hash ('-' or nothing reads stdin)")
    parser.add_argument(
        "-a", "--algorithm", choices=ALGORITHMS, default="sha256",
        help="hash algorithm (default: sha256)")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    status = 0
    files = args.files or ["-"]
    for name in files:
        try:
            if name == "-":
                chunks = iter(lambda: sys.stdin.buffer.read(65536), b"")
                digest = _digest_stream(args.algorithm, chunks)
                label = "(stdin)"
            else:
                with open(name, "rb") as handle:
                    chunks = iter(lambda: handle.read(65536), b"")
                    digest = _digest_stream(args.algorithm, chunks)
                label = name
        except OSError as exc:
            print("hashfile: cannot read %s: %s" % (name, exc), file=sys.stderr)
            status = 1
            continue
        print("%s  %s" % (digest, label))
    return status


if __name__ == "__main__":
    sys.exit(main())
