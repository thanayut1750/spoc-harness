#!/usr/bin/env python3
"""urlenc -- percent-encode or decode strings from arguments, a file, or stdin."""

import argparse
import os
import sys
import urllib.parse


def build_parser():
    parser = argparse.ArgumentParser(
        prog="urlenc",
        description="Percent-encode (default) or percent-decode text from "
                    "arguments, a file, or stdin.",
    )
    parser.add_argument(
        "strings", nargs="*",
        help="strings or file paths to process (an existing file path is "
             "read one item per line; stdin is read when omitted)")
    parser.add_argument(
        "-d", "--decode", action="store_true",
        help="decode percent-escapes instead of encoding")
    parser.add_argument(
        "-s", "--safe", default="",
        help="characters to leave unencoded (default: none)")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.strings:
        inputs = []
        for spec in args.strings:
            if os.path.isfile(spec):
                try:
                    with open(spec, "r", encoding="utf-8") as handle:
                        inputs.extend(handle.read().splitlines() or [""])
                except OSError as exc:
                    print("urlenc: cannot read %s: %s" % (spec, exc),
                          file=sys.stderr)
                    return 1
            else:
                inputs.append(spec)
    else:
        data = sys.stdin.read()
        inputs = data.splitlines() or [""]
    for item in inputs:
        if args.decode:
            print(urllib.parse.unquote(item, encoding="utf-8", errors="replace"))
        else:
            print(urllib.parse.quote(item, safe=args.safe, encoding="utf-8"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
