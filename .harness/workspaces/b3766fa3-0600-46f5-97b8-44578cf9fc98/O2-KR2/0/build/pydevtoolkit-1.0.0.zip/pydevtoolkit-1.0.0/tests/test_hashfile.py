"""Tests for pydevtoolkit.hashfile."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import hashlib
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import hashfile as mod  # noqa: E402

SHA256_HELLO_NL = "5891b5b522d5df086d0ff0b110fbd9d21bb4fc7163af34d08286a2e846f6be03"
MD5_ABC = hashlib.md5(b"abc").hexdigest()  # RFC 1321 test vector, computed
SHA1_ABC = "a9993e364706816aba3e25717850c26c9cd0d89d"


class HashfileTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_sha256_known_vector_from_stdin(self):
        code, out, err = self.run_tool(["-a", "sha256"], "hello\n")
        self.assertEqual(code, 0, err)
        self.assertIn(SHA256_HELLO_NL + "  (stdin)", out)

    def test_md5_and_sha1_known_vectors_from_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "abc.txt")
            with open(path, "wb") as handle:
                handle.write(b"abc")
            code, out, err = self.run_tool(["-a", "md5", path])
            self.assertEqual(code, 0, err)
            self.assertIn(MD5_ABC + "  " + path, out)
            code, out, err = self.run_tool(["-a", "sha1", path])
            self.assertEqual(code, 0, err)
            self.assertIn(SHA1_ABC + "  " + path, out)

    def test_missing_file_exit_nonzero(self):
        code, out, err = self.run_tool(["/nonexistent/missing.bin"])
        self.assertEqual(code, 1)
        self.assertIn("cannot read", err)

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.hashfile", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
