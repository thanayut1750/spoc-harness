#!/usr/bin/env python3
"""filesize -- human-readable sizes of files and directory trees."""

import argparse
import os
import sys

UNITS = ("B", "KB", "MB", "GB", "TB", "PB")


def _tree_size(path):
    if os.path.isfile(path) or os.path.islink(path):
        return os.path.getsize(path)
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            candidate = os.path.join(root, name)
            try:
                total += os.path.getsize(candidate)
            except OSError:
                pass
    return total


def _human(size):
    value = float(size)
    for unit in UNITS:
        if value < 1024 or unit == UNITS[-1]:
            return "%.1f %s" % (value, unit)
        value /= 1024.0
    return "%.1f %s" % (value, UNITS[-1])


def build_parser():
    parser = argparse.ArgumentParser(
        prog="filesize",
        description="Report human-readable sizes of files and directory trees.",
    )
    parser.add_argument(
        "paths", nargs="*", default=["."],
        help="files or directories (default: current directory)")
    parser.add_argument(
        "-b", "--bytes", action="store_true",
        help="print raw byte counts instead of human-readable units")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    status = 0
    for path in args.paths:
        if not os.path.exists(path):
            print("filesize: no such path: %s" % path, file=sys.stderr)
            status = 1
            continue
        size = _tree_size(path)
        if args.bytes:
            print("%d\t%s" % (size, path))
        else:
            print("%s\t%s" % (_human(size), path))
    return status


if __name__ == "__main__":
    sys.exit(main())
