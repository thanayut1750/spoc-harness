"""pydevtoolkit -- a stdlib-only collection of developer CLI utilities.

Python Dev Toolkit 1.0.0: 16 command-line developer utilities built
exclusively on the Python standard library.  Every utility module exposes:

* an argparse CLI with ``-h``/``--help``,
* a ``main(argv=None) -> int`` entry point returning 0 on success,
* support for reading input from files and/or stdin,
* seedable randomness where output is random.
"""

__version__ = "1.0.0"

#: All shipped utility module names, in README order.
TOOLS = [
    "jsonfmt", "csvstat", "hashfile", "b64",
    "urlenc", "difftxt", "regexfind", "timestamp",
    "textstat", "uniqcount", "filesize", "pickrand",
    "passwdgen", "hexdump", "utfcheck", "lorem",
]
