#!/usr/bin/env python3
"""utfcheck -- validate UTF-8 and report non-ASCII characters."""

import argparse
import sys
import unicodedata


def _char_name(char):
    try:
        return unicodedata.name(char)
    except ValueError:
        return "UNNAMED"


def build_parser():
    parser = argparse.ArgumentParser(
        prog="utfcheck",
        description="Check whether text is valid UTF-8 and report non-ASCII "
                    "characters with line and column numbers.",
    )
    parser.add_argument(
        "file", nargs="?", default="-",
        help="text file (default: '-' reads stdin)")
    parser.add_argument(
        "-m", "--max", type=int, default=10, metavar="N",
        help="maximum number of non-ASCII occurrences to list (default: 10)")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.file == "-":
            payload = sys.stdin.buffer.read()
        else:
            with open(args.file, "rb") as handle:
                payload = handle.read()
    except OSError as exc:
        print("utfcheck: cannot read %s: %s" % (args.file, exc), file=sys.stderr)
        return 1

    has_bom = payload.startswith(b"\xef\xbb\xbf")
    try:
        text = payload.decode("utf-8")
    except UnicodeDecodeError as exc:
        print("utf8: invalid (first bad byte at offset %d: %s)"
              % (exc.start, exc.reason))
        print("bom: %s" % ("yes" if has_bom else "no"))
        return 1

    print("utf8: valid")
    print("bom: %s" % ("yes" if has_bom else "no"))
    total = 0
    listed = 0
    for line_number, line in enumerate(text.splitlines(), start=1):
        for column, char in enumerate(line, start=1):
            if ord(char) > 127:
                total += 1
                if listed < max(0, args.max):
                    print("non_ascii: line=%d col=%d U+%04X %s"
                          % (line_number, column, ord(char), _char_name(char)))
                    listed += 1
    print("non_ascii_total: %d" % total)
    return 0


if __name__ == "__main__":
    sys.exit(main())
