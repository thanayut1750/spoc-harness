#!/usr/bin/env python3
"""passwdgen -- generate passwords from character classes.

By default randomness comes from the ``secrets`` module (cryptographically
strong).  ``--seed`` switches to a seeded non-cryptographic generator whose
output is reproducible -- intended for tests and demos only.
"""

import argparse
import random
import secrets
import string
import sys

LOWER = string.ascii_lowercase
UPPER = string.ascii_uppercase
DIGITS = string.digits
SYMBOLS = "!@#$%^&*()-_=+[]{};:,.?/"


def _generate(length, alphabet, rng_choice):
    return "".join(rng_choice(alphabet) for _ in range(length))


def build_parser():
    parser = argparse.ArgumentParser(
        prog="passwdgen",
        description="Generate random passwords mixing letters, digits, and "
                    "symbols (secrets-based by default).",
    )
    parser.add_argument(
        "-l", "--length", type=int, default=16, metavar="N",
        help="password length (default: 16)")
    parser.add_argument(
        "-n", "--count", type=int, default=1, metavar="N",
        help="how many passwords to generate (default: 1)")
    parser.add_argument(
        "--no-symbols", action="store_true",
        help="use letters and digits only")
    parser.add_argument(
        "--seed", type=int, default=None, metavar="INT",
        help="seeded non-cryptographic generator (deterministic; tests only)")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.length < 4:
        parser.error("--length must be >= 4")
    if args.count < 1:
        parser.error("--count must be >= 1")

    alphabet = LOWER + UPPER + DIGITS + ("" if args.no_symbols else SYMBOLS)
    if args.seed is not None:
        rng = random.Random(args.seed)
        rng_choice = rng.choice
    else:
        rng_choice = secrets.choice

    for _ in range(args.count):
        print(_generate(args.length, alphabet, rng_choice))
    return 0


if __name__ == "__main__":
    sys.exit(main())
