#!/usr/bin/env python3
"""jsonfmt -- pretty-print, compact, or key-sort JSON from a file or stdin."""

import argparse
import json
import sys


def build_parser():
    parser = argparse.ArgumentParser(
        prog="jsonfmt",
        description="Pretty-print, compact, or key-sort JSON read from a file or stdin.",
    )
    parser.add_argument(
        "file", nargs="?", default="-",
        help="JSON file to read (default: '-' reads stdin)")
    parser.add_argument(
        "-c", "--compact", action="store_true",
        help="emit compact JSON (no extra whitespace)")
    parser.add_argument(
        "-s", "--sort-keys", action="store_true",
        help="sort object keys alphabetically")
    parser.add_argument(
        "-i", "--indent", type=int, default=2, metavar="N",
        help="indent width for pretty output (default: 2)")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.file == "-":
            raw = sys.stdin.read()
        else:
            with open(args.file, "r", encoding="utf-8") as handle:
                raw = handle.read()
        data = json.loads(raw)
    except OSError as exc:
        print("jsonfmt: cannot read %s: %s" % (args.file, exc), file=sys.stderr)
        return 1
    except ValueError as exc:
        print("jsonfmt: invalid JSON: %s" % exc, file=sys.stderr)
        return 1

    if args.compact:
        out = json.dumps(data, sort_keys=args.sort_keys,
                         separators=(",", ":"), ensure_ascii=False)
    else:
        out = json.dumps(data, sort_keys=args.sort_keys,
                         indent=args.indent, ensure_ascii=False)
    print(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
