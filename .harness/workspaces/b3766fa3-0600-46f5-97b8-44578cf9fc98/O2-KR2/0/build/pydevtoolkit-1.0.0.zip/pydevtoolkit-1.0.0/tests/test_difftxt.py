"""Tests for pydevtoolkit.difftxt."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import difftxt as mod  # noqa: E402


class DifftxtTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def _write_pair(self, tmp, before, after):
        first = os.path.join(tmp, "a.txt")
        second = os.path.join(tmp, "b.txt")
        with open(first, "w", encoding="utf-8") as handle:
            handle.write(before)
        with open(second, "w", encoding="utf-8") as handle:
            handle.write(after)
        return first, second

    def test_diff_reports_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            first, second = self._write_pair(
                tmp, "alpha\nbeta\ngamma\n", "alpha\nBETA\ngamma\n")
            code, out, err = self.run_tool([first, second])
            self.assertEqual(code, 0, err)
            self.assertIn("--- %s" % first, out)
            self.assertIn("+++ %s" % second, out)
            self.assertIn("-beta\n", out)
            self.assertIn("+BETA\n", out)

    def test_identical_files_print_no_differences(self):
        with tempfile.TemporaryDirectory() as tmp:
            first, second = self._write_pair(tmp, "same\n", "same\n")
            code, out, err = self.run_tool([first, second])
            self.assertEqual(code, 0, err)
            self.assertEqual(out, "no differences\n")

    def test_zero_context_omits_unchanged_lines(self):
        with tempfile.TemporaryDirectory() as tmp:
            first, second = self._write_pair(
                tmp, "alpha\nbeta\ngamma\n", "alpha\nBETA\ngamma\n")
            code, out, err = self.run_tool(["-c", "0", first, second])
            self.assertEqual(code, 0, err)
            self.assertIn("-beta\n", out)
            self.assertIn("+BETA\n", out)
            self.assertNotIn("gamma", out)
            self.assertNotIn(" alpha\n", out)

    def test_missing_file_exit_one(self):
        code, out, err = self.run_tool(["missing_a.txt", "missing_b.txt"])
        self.assertEqual(code, 1)
        self.assertIn("difftxt:", err)
        self.assertEqual(out, "")

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.difftxt", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
