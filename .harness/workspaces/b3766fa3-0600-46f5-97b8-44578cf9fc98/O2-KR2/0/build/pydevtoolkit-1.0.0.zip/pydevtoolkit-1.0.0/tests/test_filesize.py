"""Tests for pydevtoolkit.filesize."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import filesize as mod  # noqa: E402


class FilesizeTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_bytes_flag_on_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "blob.bin")
            with open(path, "wb") as handle:
                handle.write(b"x" * 100)
            code, out, err = self.run_tool(["-b", path])
            self.assertEqual(code, 0, err)
            self.assertEqual(out, "100\t%s\n" % path)

    def test_human_readable_on_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "blob.bin")
            with open(path, "wb") as handle:
                handle.write(b"y" * 100)
            code, out, err = self.run_tool([path])
            self.assertEqual(code, 0, err)
            self.assertEqual(out, "100.0 B\t%s\n" % path)

    def test_directory_tree_sums_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            with open(os.path.join(tmp, "one.dat"), "wb") as handle:
                handle.write(b"a" * 100)
            with open(os.path.join(tmp, "two.dat"), "wb") as handle:
                handle.write(b"b" * 50)
            code, out, err = self.run_tool(["-b", tmp])
            self.assertEqual(code, 0, err)
            self.assertEqual(out, "150\t%s\n" % tmp)

    def test_missing_path_exit_one(self):
        code, out, err = self.run_tool(["no/such/path"])
        self.assertEqual(code, 1)
        self.assertIn("filesize: no such path: no/such/path", err)
        self.assertEqual(out, "")

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.filesize", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
