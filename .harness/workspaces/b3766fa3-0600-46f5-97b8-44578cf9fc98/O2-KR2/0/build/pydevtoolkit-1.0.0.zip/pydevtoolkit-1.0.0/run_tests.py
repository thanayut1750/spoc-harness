#!/usr/bin/env python3
"""Single test-run command for the Python Dev Toolkit.

    python3 run_tests.py

Discovers and runs every ``tests/test_*.py`` suite via unittest and exits 0
only when all tests pass (exit 1 on any failure or error).
"""

import os
import sys
import unittest


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    if here not in sys.path:
        sys.path.insert(0, here)
    loader = unittest.TestLoader()
    suite = loader.discover(os.path.join(here, "tests"))
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    print()
    print("Ran %d tests; failures=%d errors=%d" % (
        result.testsRun, len(result.failures), len(result.errors)))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
