"""Tests for pydevtoolkit.regexfind."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import regexfind as mod  # noqa: E402


class RegexfindTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_matches_from_stdin(self):
        code, out, err = self.run_tool([r"\d+"], "a 42 b 7\nnone\n9tail\n")
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "42\n7\n9\n")

    def test_no_matches_message(self):
        code, out, err = self.run_tool(["zzz"], "nothing here\n")
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "no matches\n")

    def test_groups_flag_prints_capture_groups(self):
        code, out, err = self.run_tool(["-g", r"(\w+)=(\d+)"], "id=42\n")
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "id=42\n  group: id\n  group: 42\n")

    def test_line_numbers_flag(self):
        code, out, err = self.run_tool(["-n", r"\d+"], "x\n5\n")
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "2:5\n")

    def test_file_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "data.txt")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("cat dog\n42 cats\n")
            code, out, err = self.run_tool([r"\d+", path])
            self.assertEqual(code, 0, err)
            self.assertEqual(out, "42\n")

    def test_bad_pattern_exit_one(self):
        code, out, err = self.run_tool(["[unclosed"])
        self.assertEqual(code, 1)
        self.assertIn("bad pattern", err)

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.regexfind", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
