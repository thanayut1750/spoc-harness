"""Test suite for the pydevtoolkit CLI utilities."""
