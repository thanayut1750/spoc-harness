"""Tests for pydevtoolkit.lorem."""

import contextlib
import io
import os
import subprocess
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import lorem as mod  # noqa: E402


class LoremTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_seeded_output_reproducible(self):
        first = self.run_tool(["-s", "9", "-w", "5"])
        second = self.run_tool(["-s", "9", "-w", "5"])
        self.assertEqual(first[0], 0)
        self.assertEqual(first, second)
        paragraph = first[1].strip()
        self.assertTrue(paragraph.endswith("."))
        self.assertTrue(paragraph[0].isupper())
        self.assertEqual(len(paragraph[:-1].split()), 5)

    def test_words_come_from_builtin_wordlist(self):
        code, out, err = self.run_tool(["-s", "4", "-w", "12"])
        self.assertEqual(code, 0, err)
        words = out.strip().rstrip(".").split()
        self.assertEqual(len(words), 12)
        self.assertTrue(set(w.lower() for w in words) <= set(mod.WORDLIST))

    def test_paragraphs_separated_by_blank_line(self):
        code, out, err = self.run_tool(["-s", "3", "-w", "4", "-p", "2"])
        self.assertEqual(code, 0, err)
        blocks = out.strip("\n").split("\n\n")
        self.assertEqual(len(blocks), 2)
        self.assertTrue(all(block.endswith(".") for block in blocks))

    def test_defaults_thirty_words(self):
        code, out, err = self.run_tool(["-s", "5"])
        self.assertEqual(code, 0, err)
        self.assertEqual(len(out.strip().rstrip(".").split()), 30)

    def test_invalid_words_rejected(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err), \
                contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(SystemExit) as ctx:
                mod.main(["-w", "0", "-s", "1"])
        self.assertEqual(ctx.exception.code, 2)
        self.assertIn("--words must be >= 1", err.getvalue())

    def test_invalid_paragraphs_rejected(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err), \
                contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(SystemExit) as ctx:
                mod.main(["-p", "0", "-s", "1"])
        self.assertEqual(ctx.exception.code, 2)
        self.assertIn("--paragraphs must be >= 1", err.getvalue())

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.lorem", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
