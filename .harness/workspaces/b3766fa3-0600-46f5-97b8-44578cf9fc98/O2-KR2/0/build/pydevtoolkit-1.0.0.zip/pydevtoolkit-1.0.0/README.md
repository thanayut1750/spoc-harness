# Python Dev Toolkit (pydevtoolkit) 1.0.0

A collection of **16 command-line developer utilities built exclusively on the
Python standard library** — no third-party dependencies, no network access,
works anywhere Python 3.8+ runs (the packaged test suite was verified with
Python 3.12.15). Every utility exposes an argparse CLI with `-h/--help`, a
`main(argv) -> int` entry point that returns 0 on success, file **and** stdin
input, and seedable randomness where output is random.

## Utility table

| Utility     | Purpose                                                            |
|-------------|--------------------------------------------------------------------|
| `jsonfmt`   | Pretty-print, compact, or key-sort JSON                            |
| `csvstat`   | CSV summary: row/column counts and min/max/mean per numeric column |
| `hashfile`  | md5/sha1/sha256 digests of files or stdin                          |
| `b64`       | Base64 encode/decode text                                          |
| `urlenc`    | Percent-encode/decode strings, files, or stdin                     |
| `difftxt`   | Unified line diff between two text files                           |
| `regexfind` | Regex matches with optional line numbers and capture groups        |
| `timestamp` | Convert epoch seconds to ISO-8601 UTC and back                     |
| `textstat`  | Line/word/char counts and estimated reading time                   |
| `uniqcount` | Word-frequency counts, sorted most-frequent first                  |
| `filesize`  | Human-readable (or raw byte) sizes of files and directory trees    |
| `pickrand`  | Pick N random lines, seedable for reproducible output              |
| `passwdgen` | Secrets-based password generator (seedable test mode)              |
| `hexdump`   | Canonical hex dump (offset, hex bytes, ASCII)                      |
| `utfcheck`  | UTF-8 validity check and non-ASCII character report                |
| `lorem`     | Placeholder text from a built-in word list, seedable               |

## Install

Verified install command (run from this directory; exits 0, offline):

```console
$ python3 -m pip install --no-build-isolation .
Successfully installed pydevtoolkit-1.0.0
```

Use `python3 -m pip` rather than bare `pip` so the package installs into
the same interpreter as `python3`; on some systems bare `pip` belongs to a
different, externally-managed Python and aborts with a PEP 668 error.

This installs the `pydevtoolkit` package and 16 console scripts
(`pydevtoolkit-jsonfmt`, `pydevtoolkit-csvstat`, ...). Each utility is also
runnable without installing, from this directory, as
`python3 -m pydevtoolkit.<tool>` — the form used in all examples below.

Offline alternative (no pip needed): `sh install.sh` copies ready-to-use
wrappers for all 16 commands into `~/.local/bin` and prints every installed
path. The `sh install.sh` form works even when an extraction tool drops the
executable bit (for example `python3 -m zipfile -e`); after `unzip`, which
preserves it, `./install.sh` works as well.

## Run the tests

Single test-run command (run from this directory; runs all 92 tests, exits 0
only if every test passes):

```console
$ python3 run_tests.py
```

## Usage examples

All examples below were captured from real runs on Python 3.12.15; the
sample files are created inline with `printf` so each block is
copy-pasteable. Commands are shown in `python3 -m pydevtoolkit.<tool>` form;
after `python3 -m pip install --no-build-isolation .` the same runs work as
`pydevtoolkit-jsonfmt -s data.json`, etc.

### jsonfmt — pretty-print, compact, sort JSON

```console
$ printf '{"name":"ada","ok":true,"nums":[3,1,2],"langs":["py","c"]}\n' > data.json
$ python3 -m pydevtoolkit.jsonfmt -s data.json
{
  "langs": [
    "py",
    "c"
  ],
  "name": "ada",
  "nums": [
    3,
    1,
    2
  ],
  "ok": true
}
$ python3 -m pydevtoolkit.jsonfmt -c data.json
{"name":"ada","ok":true,"nums":[3,1,2],"langs":["py","c"]}
```

### csvstat — CSV summary

```console
$ printf 'name,age,city\nalice,34,Oslo\nbob,28,Berlin\ncara,41,Paris\n' > people.csv
$ python3 -m pydevtoolkit.csvstat people.csv
columns: 3
data_rows: 3
name: text (3 distinct)
age: min=28 max=41 mean=34.3333 (n=3)
city: text (3 distinct)
```

Use `-d ';'` for semicolon-separated files. Text columns are counted;
numeric columns get min/max/mean.

### hashfile — md5/sha1/sha256 digests

```console
$ printf 'hello\n' > hello.txt
$ python3 -m pydevtoolkit.hashfile hello.txt
5891b5b522d5df086d0ff0b110fbd9d21bb4fc7163af34d08286a2e846f6be03  hello.txt
```

Defaults to sha256; pick another algorithm with `-a md5` or `-a sha1`, and
omit the filename to hash stdin.

### b64 — Base64 encode/decode

```console
$ printf 'encode me' | python3 -m pydevtoolkit.b64
ZW5jb2RlIG1l
```

Decode with `-d` and adjust line wrapping with `-w N` (`-w 0` disables).

### urlenc — percent encode/decode

```console
$ python3 -m pydevtoolkit.urlenc 'hello world & friends'
hello%20world%20%26%20friends
$ python3 -m pydevtoolkit.urlenc -d hello%20world%20%26%20friends
hello world & friends
```

Also accepts an existing file path (one item per line) or stdin; `-s SAFE`
leaves extra characters unencoded.

### difftxt — unified diff of two files

```console
$ printf 'alpha\nbravo\ncharlie\n' > file1.txt
$ printf 'alpha\nbravo\ncharlie delta\n' > file2.txt
$ python3 -m pydevtoolkit.difftxt file1.txt file2.txt
--- file1.txt
+++ file2.txt
@@ -1,3 +1,3 @@
 alpha
 bravo
-charlie
+charlie delta
```

Identical inputs print `no differences`; unreadable files exit 1.

### regexfind — regex matches, line numbers, groups

```console
$ printf 'alice@example.com\nnot-an-email\nbob.smith@test.io\n' > mails.txt
$ python3 -m pydevtoolkit.regexfind -n '[\w.]+@[\w.]+' mails.txt
1:alice@example.com
3:bob.smith@test.io
$ python3 -m pydevtoolkit.regexfind -g '(\w+)@([\w.]+)' mails.txt
alice@example.com
  group: alice
  group: example.com
smith@test.io
  group: smith
  group: test.io
```

Invalid regex patterns exit 1 with a clear message.

### timestamp — epoch seconds to ISO-8601 and back

```console
$ python3 -m pydevtoolkit.timestamp 1700000000
2023-11-14T22:13:20Z
$ python3 -m pydevtoolkit.timestamp 2023-11-14T22:13:20Z
1700000000
```

`--now` prints the current UTC epoch seconds; unparseable input exits 1.

### textstat — counts and reading time

```console
$ printf 'the quick brown fox\njumps over the lazy dog\nthe end\n' > poem.txt
$ python3 -m pydevtoolkit.textstat poem.txt
lines: 3
words: 11
chars: 52
reading_time: 00:03 at 200 wpm
```

Adjust the estimate with `--wpm N`.

### uniqcount — word frequency

```console
$ python3 -m pydevtoolkit.uniqcount -n 5 poem.txt
     3 the
     1 brown
     1 dog
     1 end
     1 fox
```

Counting is case-insensitive by default (`-c` disables folding); `-n N`
limits output to the top N entries.

### filesize — human-readable sizes

```console
$ python3 -m pydevtoolkit.filesize hello.txt sample.bin
6.0 B	hello.txt
23.0 B	sample.bin
$ python3 -m pydevtoolkit.filesize -b sample.bin
23	sample.bin
```

Directories are measured recursively; unknown paths exit 1.

### pickrand — random line picker (seedable)

```console
$ seq 1 10 | sed 's/^/line/' > lines.txt
$ python3 -m pydevtoolkit.pickrand -n 3 -s 42 lines.txt
line2
line1
line5
```

The same `-s 42` seed always reproduces the same picks; `-n` clamps to the
number of input lines.

### passwdgen — password generator

```console
$ python3 -m pydevtoolkit.passwdgen -l 16 -n 2 --seed 42
:odJFCrn*l+2edlB
D#]d)z.*1C5+Jau2
$ python3 -m pydevtoolkit.passwdgen -l 12 --no-symbols --seed 7
u8jzPde0IgxL
```

By default passwords come from the `secrets` module (cryptographically
strong, unique per run); `--seed INT` switches to a deterministic generator
for tests and demonstrations. `--no-symbols` restricts output to letters and
digits.

### hexdump — canonical hex view

```console
$ printf 'PYDevToolkit\000\001\002binary!\n' > sample.bin
$ python3 -m pydevtoolkit.hexdump sample.bin
00000000  50 59 44 65 76 54 6f 6f 6c 6b 69 74 00 01 02 62  |PYDevToolkit...b|
00000010  69 6e 61 72 79 21 0a                             |inary!.|
```

`-c N` sets bytes per line (default 16).

### utfcheck — UTF-8 validity and non-ASCII report

```console
$ printf 'caf\303\251 na\303\257ve \342\200\224 r\303\251sum\303\251 \360\237\230\200\nplain ascii line\n' > utf8.txt
$ python3 -m pydevtoolkit.utfcheck utf8.txt
utf8: valid
bom: no
non_ascii: line=1 col=4 U+00E9 LATIN SMALL LETTER E WITH ACUTE
non_ascii: line=1 col=8 U+00EF LATIN SMALL LETTER I WITH DIAERESIS
non_ascii: line=1 col=12 U+2014 EM DASH
non_ascii: line=1 col=15 U+00E9 LATIN SMALL LETTER E WITH ACUTE
non_ascii: line=1 col=19 U+00E9 LATIN SMALL LETTER E WITH ACUTE
non_ascii: line=1 col=21 U+1F600 GRINNING FACE
non_ascii_total: 6
```

`-m N` caps how many occurrences are listed.

### lorem — placeholder text (seedable)

```console
$ python3 -m pydevtoolkit.lorem -w 18 -p 1 -s 42
Velit elit ipsum sint magna et labore sed sint adipiscing fugiat sint mollit duis consectetur in laboris dolor.
```

`-w` words per paragraph, `-p` paragraphs (separated by blank lines), `-s`
seed for reproducible output.

## Exit codes and conventions

* `0` — success; `1` — runtime error (missing file, invalid regex,
  undecodable input, empty pick pool); `2` — command-line usage error.
* Every utility reads from a file or stdin (`-` / omitted file argument).
* Utilities with random output (`pickrand`, `passwdgen`, `lorem`) accept a
  seed flag for deterministic runs.
* Every utility has a test suite under `tests/` (92 tests total, stdlib
  `unittest` only); run them all with the single command `python3
  run_tests.py`.

## License

MIT — see the `LICENSE` file at the package root. Copyright (c) 2026 Python
Dev Toolkit contributors.
