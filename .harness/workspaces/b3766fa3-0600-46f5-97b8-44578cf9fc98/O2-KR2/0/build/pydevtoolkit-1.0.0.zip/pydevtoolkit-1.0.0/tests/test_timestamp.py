"""Tests for pydevtoolkit.timestamp."""

import contextlib
import io
import os
import subprocess
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import timestamp as mod  # noqa: E402


class TimestampTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_epoch_to_iso(self):
        code, out, err = self.run_tool(["1700000000"])
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "2023-11-14T22:13:20Z\n")

    def test_iso_zulu_to_epoch(self):
        code, out, err = self.run_tool(["2023-11-14T22:13:20Z"])
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "1700000000\n")

    def test_naive_iso_treated_as_utc(self):
        code, out, err = self.run_tool(["2023-11-14 22:13:20"])
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "1700000000\n")

    def test_negative_epoch(self):
        code, out, err = self.run_tool(["-86400"])
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "1969-12-31T00:00:00Z\n")

    def test_now_prints_current_epoch(self):
        code, out, err = self.run_tool(["--now"])
        self.assertEqual(code, 0, err)
        self.assertGreater(int(out.strip()), 1000000000)

    def test_garbage_value_exit_one(self):
        code, out, err = self.run_tool(["not-a-date"])
        self.assertEqual(code, 1)
        self.assertIn("cannot interpret", err)
        self.assertEqual(out, "")

    def test_missing_value_errors(self):
        err = io.StringIO()
        with contextlib.redirect_stderr(err), \
                contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(SystemExit) as ctx:
                mod.main([])
        self.assertEqual(ctx.exception.code, 2)
        self.assertIn("--now", err.getvalue())

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.timestamp", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
