#!/usr/bin/env python3
"""textstat -- lines, words, characters, and estimated reading time."""

import argparse
import sys


def build_parser():
    parser = argparse.ArgumentParser(
        prog="textstat",
        description="Count lines, words, and characters in text and estimate "
                    "reading time at a given words-per-minute rate.",
    )
    parser.add_argument(
        "file", nargs="?", default="-",
        help="text file (default: '-' reads stdin)")
    parser.add_argument(
        "--wpm", type=int, default=200, metavar="N",
        help="reading speed in words per minute (default: 200)")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.file == "-":
            text = sys.stdin.read()
        else:
            with open(args.file, "r", encoding="utf-8") as handle:
                text = handle.read()
    except OSError as exc:
        print("textstat: cannot read %s: %s" % (args.file, exc), file=sys.stderr)
        return 1

    lines = text.splitlines()
    words = text.split()
    wpm = max(1, args.wpm)
    seconds = round(len(words) * 60 / wpm)
    minutes, sec = divmod(seconds, 60)
    print("lines: %d" % len(lines))
    print("words: %d" % len(words))
    print("chars: %d" % len(text))
    print("reading_time: %02d:%02d at %d wpm" % (minutes, sec, wpm))
    return 0


if __name__ == "__main__":
    sys.exit(main())
