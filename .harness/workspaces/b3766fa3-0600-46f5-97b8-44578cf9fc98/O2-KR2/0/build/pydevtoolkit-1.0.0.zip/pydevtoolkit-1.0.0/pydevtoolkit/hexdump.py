#!/usr/bin/env python3
"""hexdump -- classic hex + ASCII view of a file or stdin (binascii)."""

import argparse
import binascii
import sys


def build_parser():
    parser = argparse.ArgumentParser(
        prog="hexdump",
        description="Show a canonical hex dump (offset, hex bytes, ASCII) of "
                    "a file or stdin.",
    )
    parser.add_argument(
        "file", nargs="?", default="-",
        help="input file (default: '-' reads stdin)")
    parser.add_argument(
        "-c", "--columns", type=int, default=16, metavar="N",
        help="bytes per line (default: 16)")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    width = max(1, args.columns)
    try:
        if args.file == "-":
            payload = sys.stdin.buffer.read()
        else:
            with open(args.file, "rb") as handle:
                payload = handle.read()
    except OSError as exc:
        print("hexdump: cannot read %s: %s" % (args.file, exc), file=sys.stderr)
        return 1

    for offset in range(0, len(payload), width):
        chunk = payload[offset:offset + width]
        chunk_hex = binascii.hexlify(chunk).decode("ascii")
        pairs = " ".join(chunk_hex[i:i + 2] for i in range(0, len(chunk_hex), 2))
        padded = pairs.ljust(width * 3 - 1)
        ascii_part = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
        print("%08x  %s  |%s|" % (offset, padded, ascii_part))
    return 0


if __name__ == "__main__":
    sys.exit(main())
