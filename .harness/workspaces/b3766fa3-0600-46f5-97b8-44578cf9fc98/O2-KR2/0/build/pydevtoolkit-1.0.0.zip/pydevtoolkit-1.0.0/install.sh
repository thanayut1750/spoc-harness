#!/bin/sh
# install.sh -- Python Dev Toolkit 1.0.0 offline installer.
#
# Copies executable wrappers for all 16 utilities into ~/.local/bin and
# prints every installed path.  Pure POSIX shell; no network access.
set -e

SRC="$(cd "$(dirname "$0")" && pwd)"
BIN="${HOME}/.local/bin"

if [ ! -d "$SRC/pydevtoolkit" ]; then
    echo "install.sh: cannot find pydevtoolkit/ next to $0" >&2
    exit 1
fi

mkdir -p "$BIN"

for tool in jsonfmt csvstat hashfile b64 urlenc difftxt regexfind timestamp \
            textstat uniqcount filesize pickrand passwdgen hexdump utfcheck lorem; do
    wrapper="$BIN/$tool"
    {
        echo '#!/bin/sh'
        echo "# Installed by pydevtoolkit-1.0.0 install.sh"
        echo "PYTHONPATH=\"$SRC\${PYTHONPATH:+:\$PYTHONPATH}\" exec \"\${PYTHON:-python3}\" -m pydevtoolkit.$tool \"\$@\""
    } > "$wrapper"
    chmod +x "$wrapper"
    echo "installed: $wrapper"
done

echo
echo "Python Dev Toolkit 1.0.0 installed: 16 commands in $BIN"
echo "Make sure $BIN is on your PATH, then try: jsonfmt --help"
