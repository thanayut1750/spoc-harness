#!/usr/bin/env python3
"""lorem -- generate deterministic placeholder text from a built-in wordlist."""

import argparse
import random
import sys

WORDLIST = (
    "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod "
    "tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam "
    "quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo "
    "consequat duis aute irure in reprehenderit voluptate velit esse cillum "
    "fugiat nulla pariatur excepteur sint occaecat cupidatat non proident "
    "sunt culpa qui officia deserunt mollit anim id est laborum"
).split()


def _paragraph(rng, words):
    picked = [rng.choice(WORDLIST) for _ in range(words)]
    sentence = " ".join(picked)
    return sentence[0].upper() + sentence[1:] + "."


def build_parser():
    parser = argparse.ArgumentParser(
        prog="lorem",
        description="Generate placeholder paragraphs from a built-in word "
                    "list; seedable for reproducible text.",
    )
    parser.add_argument(
        "-w", "--words", type=int, default=30, metavar="N",
        help="words per paragraph (default: 30)")
    parser.add_argument(
        "-p", "--paragraphs", type=int, default=1, metavar="N",
        help="number of paragraphs (default: 1)")
    parser.add_argument(
        "-s", "--seed", type=int, default=None, metavar="INT",
        help="random seed for reproducible output")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.words < 1:
        parser.error("--words must be >= 1")
    if args.paragraphs < 1:
        parser.error("--paragraphs must be >= 1")
    rng = random.Random(args.seed)
    for index in range(args.paragraphs):
        if index:
            print()
        print(_paragraph(rng, args.words))
    return 0


if __name__ == "__main__":
    sys.exit(main())
