"""Tests for pydevtoolkit.textstat."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import textstat as mod  # noqa: E402


class TextstatTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_counts_from_stdin(self):
        text = "hello world\nsecond line here\n"
        code, out, err = self.run_tool([], text)
        self.assertEqual(code, 0, err)
        self.assertEqual(
            out,
            "lines: 2\nwords: 5\nchars: %d\nreading_time: 00:02 at 200 wpm\n"
            % len(text))

    def test_custom_wpm(self):
        code, out, err = self.run_tool(["--wpm", "100"], "one two three four five\n")
        self.assertEqual(code, 0, err)
        self.assertIn("reading_time: 00:03 at 100 wpm", out)

    def test_file_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "doc.txt")
            body = "alpha beta\n\nlast\n"
            with open(path, "w", encoding="utf-8") as handle:
                handle.write(body)
            code, out, err = self.run_tool([path])
            self.assertEqual(code, 0, err)
            self.assertIn("lines: 3", out)
            self.assertIn("words: 3", out)
            self.assertIn("chars: %d" % len(body), out)

    def test_missing_file_exit_one(self):
        code, out, err = self.run_tool(["no_such_file.txt"])
        self.assertEqual(code, 1)
        self.assertIn("cannot read", err)
        self.assertEqual(out, "")

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.textstat", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
