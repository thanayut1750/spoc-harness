#!/usr/bin/env python3
"""csvstat -- column counts plus min/max/mean for numeric CSV columns."""

import argparse
import csv
import sys


def _column_stats(values):
    """Return ('empty', None-like) or stats dict, or None when non-numeric."""
    numeric = []
    for value in values:
        if value == "":
            continue
        try:
            numeric.append(float(value))
        except ValueError:
            return None
    if not numeric:
        return "empty"
    return {
        "min": min(numeric),
        "max": max(numeric),
        "mean": sum(numeric) / len(numeric),
        "count": len(numeric),
    }


def _fmt(number):
    number = float(number)
    if number.is_integer():
        return str(int(number))
    return repr(number)


def build_parser():
    parser = argparse.ArgumentParser(
        prog="csvstat",
        description="Summarize a CSV file: row/column counts and min/max/mean "
                    "for every numeric column.",
    )
    parser.add_argument(
        "file", nargs="?", default="-",
        help="CSV file to read (default: '-' reads stdin)")
    parser.add_argument(
        "-d", "--delimiter", default=",",
        help="single-character field delimiter (default: ',')")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.file == "-":
            text = sys.stdin.read()
            rows = list(csv.reader(text.splitlines(), delimiter=args.delimiter))
        else:
            with open(args.file, "r", encoding="utf-8", newline="") as handle:
                rows = list(csv.reader(handle, delimiter=args.delimiter))
    except OSError as exc:
        print("csvstat: cannot read %s: %s" % (args.file, exc), file=sys.stderr)
        return 1

    if not rows:
        print("csvstat: input is empty", file=sys.stderr)
        return 1

    header = rows[0]
    data = rows[1:]
    ncols = len(header)
    print("columns: %d" % ncols)
    print("data_rows: %d" % len(data))
    for idx in range(ncols):
        name = header[idx] if idx < len(header) else "col%d" % (idx + 1)
        values = [row[idx] for row in data if idx < len(row)]
        stats = _column_stats(values)
        if stats is None:
            print("%s: text (%d distinct)" % (name, len(set(values))))
        elif stats == "empty":
            print("%s: empty" % name)
        else:
            print("%s: min=%s max=%s mean=%.4f (n=%d)"
                  % (name, _fmt(stats["min"]), _fmt(stats["max"]),
                     stats["mean"], stats["count"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
