#!/usr/bin/env python3
"""uniqcount -- word frequency counts sorted most-common-first."""

import argparse
import collections
import sys


def build_parser():
    parser = argparse.ArgumentParser(
        prog="uniqcount",
        description="Count word frequencies in text and print them sorted "
                    "(most frequent first, ties alphabetical).",
    )
    parser.add_argument(
        "file", nargs="?", default="-",
        help="text file (default: '-' reads stdin)")
    parser.add_argument(
        "-n", "--top", type=int, default=0, metavar="N",
        help="show only the first N entries (0 = all)")
    parser.add_argument(
        "-c", "--case-sensitive", action="store_true",
        help="do not fold case before counting")
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.file == "-":
            text = sys.stdin.read()
        else:
            with open(args.file, "r", encoding="utf-8") as handle:
                text = handle.read()
    except OSError as exc:
        print("uniqcount: cannot read %s: %s" % (args.file, exc), file=sys.stderr)
        return 1

    if not args.case_sensitive:
        text = text.lower()
    words = [word for word in text.split() if word]
    counts = collections.Counter(words)
    ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    if args.top and args.top > 0:
        ordered = ordered[:args.top]
    for word, count in ordered:
        print("%6d %s" % (count, word))
    return 0


if __name__ == "__main__":
    sys.exit(main())
