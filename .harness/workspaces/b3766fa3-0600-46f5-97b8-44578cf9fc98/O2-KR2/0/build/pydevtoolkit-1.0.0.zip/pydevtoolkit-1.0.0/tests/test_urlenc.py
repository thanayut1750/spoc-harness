"""Tests for pydevtoolkit.urlenc."""

import contextlib
import io
import os
import subprocess
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pydevtoolkit import urlenc as mod  # noqa: E402


class UrlencTests(unittest.TestCase):
    def run_tool(self, argv, stdin_text=""):
        out, err = io.StringIO(), io.StringIO()
        old_stdin = sys.stdin
        sys.stdin = io.TextIOWrapper(io.BytesIO(stdin_text.encode("utf-8")))
        try:
            with contextlib.redirect_stdout(out), \
                    contextlib.redirect_stderr(err):
                code = mod.main(argv)
        finally:
            sys.stdin = old_stdin
        return code, out.getvalue(), err.getvalue()

    def test_encode_from_argument(self):
        code, out, err = self.run_tool(["hello world & friends"])
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "hello%20world%20%26%20friends\n")

    def test_decode_from_stdin(self):
        code, out, err = self.run_tool(["-d"], "hello%20world%20%26%20friends\n")
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "hello world & friends\n")

    def test_safe_characters_left_unencoded(self):
        code, out, err = self.run_tool(["-s", "/", "a/b c"])
        self.assertEqual(code, 0, err)
        self.assertEqual(out, "a/b%20c\n")

    def test_file_input_multi_line(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "lines.txt")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("one two\nthree four\n")
            code, out, err = self.run_tool([path])
            self.assertEqual(code, 0, err)
            self.assertEqual(out, "one%20two\nthree%20four\n")

    def test_help_exit_zero(self):
        proc = subprocess.run(
            [sys.executable, "-m", "pydevtoolkit.urlenc", "--help"],
            cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL, universal_newlines=True)
        self.assertEqual(proc.returncode, 0)
        self.assertIn("usage:", proc.stdout)


if __name__ == "__main__":
    unittest.main()
